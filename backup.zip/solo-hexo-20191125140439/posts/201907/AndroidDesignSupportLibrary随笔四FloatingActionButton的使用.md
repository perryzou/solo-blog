title: Android Design Support Library 随笔(四)-FloatingActionButton的使用
date: '2019-07-19 11:34:52'
updated: '2019-07-19 11:34:52'
tags: [Android, AndroidDesign]
permalink: /articles/2019/07/19/1563507292819.html
---

---
## 不一样的Button - FloatingActionButton
---
google在`Design`库里面加入的一种悬浮按钮,效果看下面图片
![fab][1]
<!-- more -->

---
> 第一篇地址: [Android Design Support Library 随笔(一)](http://perryzou.com/articles/2019/07/19/1563506652674.html)
> 第二篇地址: [Android Design Support Library 随笔(二)-TextInputLayout的使用](http://perryzou.com/articles/2019/07/19/1563507005213.html)
> 第三篇地址: [Android Design Support Library 随笔(三)-Snackbar的使用](http://perryzou.com/articles/2019/07/19/1563507145053.html)

---
个人看来,其实`FloatingActionButton`用起来和`ImageButton`并没有什么区别,只是封装了一些方法.
上面的例子中的2个`FloatingActionButton`代码如下,很简单
```
    <android.support.design.widget.FloatingActionButton
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:src="@mipmap/ic_launcher" />

    <android.support.design.widget.FloatingActionButton
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="right|bottom"
        android:layout_margin="@dimen/activity_horizontal_margin"
        android:src="@mipmap/ic_launcher"
        app:backgroundTint="#ff87ffeb"
        app:elevation="6dp"
        app:pressedTranslationZ="12dp"
        app:rippleColor="#33728dff" />
```
src里面放图片就可以了,其中`backgroundTint`指的是背景色,`elevation`指的的是阴影,`pressedTranslationZ`按下按钮阴影的宽度,这里比`elevation`的值大就可以了,`rippleColor`点击的边缘阴影颜色,还有一些其他属性,但一般都不常用,这里就不说明了.

---
## 动画,搭配RecyclerView使用
---
![fab_gif][2]

我们一般用到`FloatingActionButton`的时候都是上面这种清空,搭配recycler使用,
上面的代码需要在`xml`里面添加这句代码
```
app:layout_behavior="com.perryzou.designlibrary.fab.ScrollBehavior"
```
其中`ScrollBehavior`是自定义的`ScrollBehavior`,源码如下,摘取自网络.
```
public class ScrollBehavior extends FloatingActionButton.Behavior {
    private static final Interpolator INTERPOLATOR = new FastOutSlowInInterpolator();
    private boolean mIsAnimatingOut = false;

    public ScrollBehavior(Context context, AttributeSet attrs) {
        super();
    }

    @Override
    public boolean onStartNestedScroll(final CoordinatorLayout coordinatorLayout, final FloatingActionButton child,
                                       final View directTargetChild, final View target, final int nestedScrollAxes) {
        // Ensure we react to vertical scrolling
        return nestedScrollAxes == ViewCompat.SCROLL_AXIS_VERTICAL
                || super.onStartNestedScroll(coordinatorLayout, child, directTargetChild, target, nestedScrollAxes);
    }

    @Override
    public void onNestedScroll(final CoordinatorLayout coordinatorLayout, final FloatingActionButton child,
                               final View target, final int dxConsumed, final int dyConsumed,
                               final int dxUnconsumed, final int dyUnconsumed) {
        super.onNestedScroll(coordinatorLayout, child, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
        if (dyConsumed > 0 && !this.mIsAnimatingOut && child.getVisibility() == View.VISIBLE) {
            // User scrolled down and the FAB is currently visible -> hide the FAB
            animateOut(child);
        } else if (dyConsumed < 0 && child.getVisibility() != View.VISIBLE) {
            // User scrolled up and the FAB is currently not visible -> show the FAB
            animateIn(child);
        }
    }

    // Same animation that FloatingActionButton.Behavior uses to hide the FAB when the AppBarLayout exits
    private void animateOut(final FloatingActionButton button) {
        ViewCompat.animate(button).translationY(button.getHeight() + getMarginBottom(button)).setInterpolator(INTERPOLATOR).withLayer()
                .setListener(new ViewPropertyAnimatorListener() {
                    public void onAnimationStart(View view) {
                        mIsAnimatingOut = true;
                    }

                    public void onAnimationCancel(View view) {
                        mIsAnimatingOut = false;
                    }

                    public void onAnimationEnd(View view) {
                        mIsAnimatingOut = false;
                        view.setVisibility(View.GONE);
                    }
                }).start();
    }

    // Same animation that FloatingActionButton.Behavior uses to show the FAB when the AppBarLayout enters
    private void animateIn(FloatingActionButton button) {
        button.setVisibility(View.VISIBLE);
        ViewCompat.animate(button).translationY(0)
                .setInterpolator(INTERPOLATOR).withLayer().setListener(null)
                .start();
    }

    private int getMarginBottom(View v) {
        int marginBottom = 0;
        final ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        if (layoutParams instanceof ViewGroup.MarginLayoutParams) {
            marginBottom = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
        }
        return marginBottom;
    }
}
```
上面的代码很简单,稍微一看就明白了,我不就阐述了.
**注意:父级布局必须是`CoordinatorLayout`才能正常使用,不然没有动画效果.`CoordinatorLayout`用法我会在这个系列里面讲到**
`FloatingActionButton`的大致用法就这些,但我并不推荐使用,有点鸡肋这个东西.
下一篇我会阐述下`TabLayout`的用法

  [1]: http://img.perryzou.com/fab_1.png?imageView2/0/
  [2]: http://img.perryzou.com/fab.gif