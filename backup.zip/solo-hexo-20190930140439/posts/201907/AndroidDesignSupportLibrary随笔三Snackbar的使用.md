title: Android Design Support Library 随笔(三)-Snackbar的使用
date: '2019-07-19 11:32:25'
updated: '2019-07-19 11:32:25'
tags: [Android, AndroidDesign]
permalink: /articles/2019/07/19/1563507145053.html
---

---
## 什么是Snackbar?
---
`Snackbar`是一个类似与`Toast`的弹出似的提示框,里面比`Toast`多出了图标,按钮,按钮事件等要素,`Snackbar`是从底下弹出,具体效果请参照下图.

![simple_snackbar](http://img.perryzou.com/snack_1.gif?imageView2/2)
<!-- more -->

---
> 第一篇地址: [Android Design Support Library 随笔(一)](http://perryzou.com/articles/2019/07/19/1563506652674.html)
> 第二篇地址: [Android Design Support Library 随笔(二)-TextInputLayout的使用](http://perryzou.com/articles/2019/07/19/1563507005213.html)

---

## 简单的Snackbar
---

上面的代码很简单:
```
Snackbar.make(contentView, "简单的SnackBar", Snackbar.LENGTH_SHORT).show();
```
是不是很简单,显示起来跟`Toast`没有什么区别.
需要注意的是`Snackbar`需要一个容器来容纳他,这点跟Toast不一样,我上面的例子是直接传的`Activity`的根布局,官网推荐跟`CoordinatorLayout`一起使用,这样和Design的库的其他组件有很多交互,我在以后的文章里面会介绍到.
```
Snackbar.make(contentView, "简单的SnackBar", Snackbar.LENGTH_LONG)                                 
         .setAction("按钮", new View.OnClickListener() {                                           
             @Override                                                                           
             public void onClick(View v) {                                                       
                 Toast.makeText(MainActivity.this, "点击了按钮", Toast.LENGTH_SHORT).show();          
             }                                                                                   
         })                                                                                      
         .setCallback(new Snackbar.Callback() {                                                  
             @Override                                                                           
             public void onDismissed(Snackbar snackbar, int event) {                             
                 super.onDismissed(snackbar, event);                                             
                 Toast.makeText(MainActivity.this, "Snackbar 关闭了", Toast.LENGTH_SHORT).show();   
             }                                                                                   
             @Override                                                                           
             public void onShown(Snackbar snackbar) {                                            
                 super.onShown(snackbar);                                                        
                 Toast.makeText(MainActivity.this, "Snackbar 打开了", Toast.LENGTH_SHORT).show();   
             }                                                                                   
         }).show();                                                                                                                                                                      
```
上面这个是带按钮的`Snackbar`,并且对它的打开和关闭实现了回调,只需要`setCallback`就可以了.

---
## 自定义Sanckbar
---
### 更改颜色
查看`Snackbar`的源码发现,它自己封装了一个`SnackbarLayout`继承自`LinearLayout`,源码如下:
```
<merge xmlns:android="http://schemas.android.com/apk/res/android">

    <TextView
            android:id="@+id/snackbar_text"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:paddingTop="@dimen/design_snackbar_padding_vertical"
            android:paddingBottom="@dimen/design_snackbar_padding_vertical"
            android:paddingLeft="@dimen/design_snackbar_padding_horizontal"
            android:paddingRight="@dimen/design_snackbar_padding_horizontal"
            android:textAppearance="@style/TextAppearance.Design.Snackbar.Message"
            android:maxLines="@integer/design_snackbar_text_max_lines"
            android:layout_gravity="center_vertical|left|start"
            android:ellipsize="end"
            android:textAlignment="viewStart"/>

    <Button
            android:id="@+id/snackbar_action"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginLeft="@dimen/design_snackbar_extra_spacing_horizontal"
            android:layout_marginStart="@dimen/design_snackbar_extra_spacing_horizontal"
            android:layout_gravity="center_vertical|right|end"
            android:paddingTop="@dimen/design_snackbar_padding_vertical"
            android:paddingBottom="@dimen/design_snackbar_padding_vertical"
            android:paddingLeft="@dimen/design_snackbar_padding_horizontal"
            android:paddingRight="@dimen/design_snackbar_padding_horizontal"
            android:visibility="gone"
            android:textColor="?attr/colorAccent"
            style="?attr/borderlessButtonStyle"/>

</merge>
```
很简单就一个`TextView`和`Button`,找到布局了我们就可以随便修改了,
```
Snackbar snackbar = Snackbar.make(contentView, "带颜色的SnackBar", Snackbar.LENGTH_SHORT);
View view = snackbar.getView();//获取Snackbar的view
view.setBackgroundColor(Color.parseColor("#00FF00"));//修改view的背景色
((TextView) view.findViewById(R.id.snackbar_text))
                .setTextColor(Color.parseColor("#C71585"));//修改字体颜色
snackbar.show();
```
![color_snack](http://img.perryzou.com/snack_2.png?imageView2/2/0)

当然你还可以不仅仅这样,获得了Textview和Button对象后,你能干的事情就多了,动画啊这些随便发挥了
这里我就不细说了.

### 添加View
上面说到`Snackbar`封装了一个`SnackbarLayout`继承自`LinearLayout`,so 我们想加view的话,获得对象话的直接往里面加就是了.
```
Snackbar snackbar = Snackbar.make(contentView, "SnackBar添加View", Snackbar.LENGTH_SHORT);

Snackbar.SnackbarLayout snackbarLayout = (Snackbar.SnackbarLayout) snackbar.getView();

View add_view = LayoutInflater.from(this).inflate(R.layout.custome, null);

LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

p.gravity = Gravity.CENTER_VERTICAL;

snackbarLayout.addView(add_view, 0, p);
snackbar.show();
```
![add_view](http://img.perryzou.com/snack_3.png?imageView2/2/0)

你可以自行发挥.
上面的更改颜色,添加view如果项目上面使用Snackbar很多的话,建议封装一下,我这里发现有个封装得很好的例子,摘取自博客 [没时间解释了，快使用Snackbar!——Android Snackbar花式使用指南][1]
```
/**
 * Created by 赵晨璞 on 2016/5/1.
 */
public class SnackbarUtil {

public static final   int Info = 1;
public static final  int Confirm = 2;
public static final  int Warning = 3;
public static final  int Alert = 4;


public static  int red = 0xfff44336;
public static  int green = 0xff4caf50;
public static  int blue = 0xff2195f3;
public static  int orange = 0xffffc107;

/**
 * 短显示Snackbar，自定义颜色
 * @param view
 * @param message
 * @param messageColor
 * @param backgroundColor
 * @return
 */
public static Snackbar ShortSnackbar(View view, String message, int messageColor, int backgroundColor){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_SHORT);
    setSnackbarColor(snackbar,messageColor,backgroundColor);
    return snackbar;
}

/**
 * 长显示Snackbar，自定义颜色
 * @param view
 * @param message
 * @param messageColor
 * @param backgroundColor
 * @return
 */
public static Snackbar LongSnackbar(View view, String message, int messageColor, int backgroundColor){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_LONG);
    setSnackbarColor(snackbar,messageColor,backgroundColor);
    return snackbar;
}

/**
 * 自定义时常显示Snackbar，自定义颜色
 * @param view
 * @param message
 * @param messageColor
 * @param backgroundColor
 * @return
 */
public static Snackbar IndefiniteSnackbar(View view, String message,int duration,int messageColor, int backgroundColor){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_INDEFINITE).setDuration(duration);
    setSnackbarColor(snackbar,messageColor,backgroundColor);
    return snackbar;
}

/**
 * 短显示Snackbar，可选预设类型
 * @param view
 * @param message
 * @param type
 * @return
 */
public static Snackbar ShortSnackbar(View view, String message, int type){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_SHORT);
    switchType(snackbar,type);
    return snackbar;
}

/**
 * 长显示Snackbar，可选预设类型
 * @param view
 * @param message
 * @param type
 * @return
 */
public static Snackbar LongSnackbar(View view, String message,int type){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_LONG);
    switchType(snackbar,type);
    return snackbar;
}

/**
 * 自定义时常显示Snackbar，可选预设类型
 * @param view
 * @param message
 * @param type
 * @return
 */
public static Snackbar IndefiniteSnackbar(View view, String message,int duration,int type){
    Snackbar snackbar = Snackbar.make(view,message, Snackbar.LENGTH_INDEFINITE).setDuration(duration);
    switchType(snackbar,type);
    return snackbar;
}

//选择预设类型
private static void switchType(Snackbar snackbar,int type){
    switch (type){
        case Info:
            setSnackbarColor(snackbar,blue);
            break;
        case Confirm:
            setSnackbarColor(snackbar,green);
            break;
        case Warning:
            setSnackbarColor(snackbar,orange);
            break;
        case Alert:
            setSnackbarColor(snackbar,Color.YELLOW,red);
            break;
    }
}

/**
 * 设置Snackbar背景颜色
 * @param snackbar
 * @param backgroundColor
 */
public static void setSnackbarColor(Snackbar snackbar, int backgroundColor) {
    View view = snackbar.getView();
    if(view!=null){
        view.setBackgroundColor(backgroundColor);
    }
}

/**
 * 设置Snackbar文字和背景颜色
 * @param snackbar
 * @param messageColor
 * @param backgroundColor
 */
public static void setSnackbarColor(Snackbar snackbar, int messageColor, int backgroundColor) {
    View view = snackbar.getView();
    if(view!=null){
        view.setBackgroundColor(backgroundColor);
        ((TextView) view.findViewById(R.id.snackbar_text)).setTextColor(messageColor);
    }
}

/**
 * 向Snackbar中添加view
 * @param snackbar
 * @param layoutId
 * @param index 新加布局在Snackbar中的位置
 */
public static void SnackbarAddView( Snackbar snackbar,int layoutId,int index) {
    View snackbarview = snackbar.getView();
    Snackbar.SnackbarLayout snackbarLayout=(Snackbar.SnackbarLayout)snackbarview;

    View add_view = LayoutInflater.from(snackbarview.getContext()).inflate(layoutId,null);

    LinearLayout.LayoutParams p = new LinearLayout.LayoutParams( LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
    p.gravity= Gravity.CENTER_VERTICAL;

    snackbarLayout.addView(add_view,index,p);
}

}
```
简单使用方法:
```
SnackbarUtil.ShortSnackbar(contentView,"新消息",SnackbarUtil.Info).show();
```
差不多就这样了,如果你有更好的使用方式,欢迎给我留言
下一篇会简单介绍下`Floating Action Button`,源码我会在整个`design`系列完成后放出

  [1]: http://www.jianshu.com/p/cd1e80e64311 