title: Android Design Support Library 随笔(一)
date: '2019-07-19 11:24:12'
updated: '2019-07-19 11:27:31'
tags: [Android, AndroidDesign]
permalink: /articles/2019/07/19/1563506652674.html
---
![](https://img.hacpai.com/bing/20190413.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

Android推出`Design library`后一直没怎么了解,最近几天看了下网上的大牛,自己使用了一下,不得不对Google点个赞.这里记下一点使用心得,
<!-- more -->
## Design library 包含组件

> TextInputLayout  - [Android Design Support Library 随笔(二)-TextInputLayout的使用](/2015/07/27/android-design-libary-2/)
> Snackbar  -   [Android Design Support Library 随笔(三)-Snackbar的使用](/2016/09/21/android-design-libary-3/)
> Floating Action Button    -   [Android Design Support Library 随笔(四)-FloatingActionButton的使用](/2016/09/22/android-design-libary-4//)
> TabLayout     -   [Android Design Support Library 随笔(五)-TabLayout的使用](/2016/09/22/android-design-libary-5//)
> NavigationView    -   [撰写中](/#)
> AppBarLayout    -   [撰写中](/#)
> CoordinatorLayout    -   [撰写中](/#)
> CollapsingToolbarLayout    -   [撰写中](/#)

组件用法请参考我的后续文章:


## 使用方法

### 首先
>肯定是要下载Android Design Support Library.打开Sdk manager (Android SDK根目录),载入后滚动到最下面选择`Extras`下面的`Android Support Libary` 然后点击下面的install就可以了
>如果无法访问请参考的我的另一篇文章[科学上网的一些小东西](/2015/07/24/science-internet/)

![SDK Manager](http://img.perryzou.com/20150724145149.png?imageView2/0/)

### 下载好了就更新在项目里面使用了,我这里只讲Android Studio 的使用方法
在项目的`build.gradle`中添加下面代码就可以使用了,其中版本号可以修改
```
dependencies {
    compile 'com.android.support:design:22.2.0'
}
```

---
## 结束语
最近项目上面很忙,没时间写具体点,更新也慢,真的很烦心.