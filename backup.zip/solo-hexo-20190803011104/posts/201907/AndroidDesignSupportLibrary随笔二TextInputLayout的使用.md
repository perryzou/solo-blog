title: Android Design Support Library 随笔(二)-TextInputLayout的使用
date: '2019-07-19 11:30:05'
updated: '2019-07-19 11:30:22'
tags: [Android, AndroidDesign]
permalink: /articles/2019/07/19/1563507005213.html
---

---
## 什么是TextInputLayout?
---

`TextInputLayout`是一个包含`Editetext`的父容器控件,给`Editetext`的`hint`提示提供一个动画效果,具体效果请参照下图.
![TextInputLayout](http://img.perryzou.com/jkl.gif)
<!-- more -->

---
> 第一篇地址: [Android Design Support Library 随笔(一)](http://perryzou.com/articles/2019/07/19/1563506652674.html)

---
## 使用方法

`TextInputLayout`的使用方法很简单,直接在`Editetext`的外层包一个`TextInputLayout`的就可以了,

```
 <android.support.design.widget.TextInputLayout
        
        android:id="@+id/textInput"
        android:layout_width="match_parent"
        android:layout_height="wrap_content">

        <EditText
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:hint="请输入姓名:"/>
    </android.support.design.widget.TextInputLayout>
```
如果要使用`TextInputLayout`的错误提示,就要在代码里面监听`Editetext`的输入事件,来动态的改变`TextInputLayout`的状态.
```
editText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (s.length()>4){
                        inputLayout.setErrorEnabled(true);
                        inputLayout.setError("姓名长度不能超过4个");
                    }else{
                        inputLayout.setErrorEnabled(false);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
```
    注明,如果默认页面打开的焦点在Editetext上面的话,`TextInputLayout`会直接把`hint`移动到上面,
## 总结
`TextInputLayout`的使用方法就是这样,是不是很简单,快点去使用吧.
下一章我会讲解`Snackbar`的使用方法