title: Android Design Support Library 随笔(五)-TabLayout的使用
date: '2019-07-19 11:39:11'
updated: '2019-07-19 11:39:11'
tags: [Android, AndroidDesign]
permalink: /articles/2019/07/19/1563507551750.html
---

---
## 导航tab的另一种实现方式-TabLayout
---
tab控件大家一定不会陌生,比如QQ,微信底部的导航栏.之前基本上都需要自己实现,或者用一些第三方控件,现在google 推出的`design`库里面自带了这个控件,具体效果如下图,使用起来相当方便
![fab][1]
<!-- more -->


---
> 第一篇地址: [Android Design Support Library 随笔(一)](http://perryzou.com/articles/2019/07/19/1563506652674.html)
> 第二篇地址: [Android Design Support Library 随笔(二)-TextInputLayout的使用](http://perryzou.com/articles/2019/07/19/1563507005213.html)
> 第三篇地址: [Android Design Support Library 随笔(三)-Snackbar的使用](http://perryzou.com/articles/2019/07/19/1563507145053.html)
> 第四篇地址: [Android Design Support Library 随笔(四)-FloatingActionButton的使用](http://perryzou.com/articles/2019/07/19/1563507292819.html)

---

上面图中只添加了一个`TabLayout`和一个`ViewPager`,布局文件如下:
```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools"
    android:id="@+id/activity_tab_layout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    tools:context="com.perryzou.designlibrary.TabLayoutActivity">

    <android.support.design.widget.TabLayout
        android:id="@+id/tabLayout"
        android:layout_width="match_parent"
        android:layout_height="wrap_content" />

    <android.support.v4.view.ViewPager
        android:id="@+id/viewPager"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:background="#ffffff" />
</LinearLayout>
```
其中`TabLayout`就是一个普通的view,这里我是放在了`ViewPager`的上方,像QQ,微信是放在了下方.
然后Activity的代码:
```
public class TabLayoutActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_layout);
        initView();
    }

    private void initView() {
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        viewPager = (ViewPager) findViewById(R.id.viewPager);

        viewPager.setAdapter(new TabPageAdapter(getSupportFragmentManager()));
        ////TabLayout关联pager
        tabLayout.setupWithViewPager(viewPager);
    }
}
```
其中`TabPageAdapter`的代码:
```
public class TabPageAdapter extends FragmentPagerAdapter {
    public TabPageAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return TabFragment.newInstance(position);
    }

    @Override
    public int getCount() {
        return 5;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "page"+position;
    }
}
```
`TabFragment`的代码我就不放出来了,就显示了一个简单的文本.
其中Activity中`setupWithViewPager`就是把`TabLayout`关联`ViewPager`,运行下,就有了上面的效果.
其中`Tablayout`显示的title是`PageAdapter`的`getPageTitle`的值 

---
## TabLayout 属性详解
---

上面简单的实现了一个`TabLayout`,更加自定义的方式请参考下方
```
    <android.support.design.widget.TabLayout
        android:id="@+id/tab1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:tabGravity="fill"
        app:tabIndicatorColor="@color/blue"
        app:tabIndicatorHeight="5dp"
        app:tabMode="fixed" />

    <android.support.design.widget.TabLayout
        android:id="@+id/tab2"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="@dimen/activity_horizontal_margin"
        app:tabGravity="center"
        app:tabIndicatorColor="@color/red"
        app:tabIndicatorHeight="10dp"
        app:tabMode="fixed" />

    <android.support.design.widget.TabLayout
        android:id="@+id/tab3"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="@dimen/activity_horizontal_margin"
        app:tabGravity="fill"
        app:tabIndicatorColor="@color/green"
        app:tabIndicatorHeight="15dp"
        app:tabMode="scrollable" />

    <android.support.design.widget.TabLayout
        android:id="@+id/tab4"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="@dimen/activity_horizontal_margin"
        app:tabGravity="center"
        app:tabIndicatorColor="@color/green"
        app:tabIndicatorHeight="15dp"
        app:tabMode="scrollable" />
```
这里显示了四个不一样的tab.
`tabIndicatorColor`指的的文字下方线条的颜色
`tabIndicatorHeight`是线条高度.
`tabGravity`是`Tablayout`的位置关系,有`center`和`fill`2种,当tab数量很少的时候有用
`tabMode`是指`Tablayout`滚动方式,有2个值`fixed`,`scrollable`,`fixed`不允许,会把tab平均分配宽度,`scrollable`运行滚动,每个tab默认宽度,当超过屏幕宽度时候,可以滚动,具体看下图效果
![tab_1][2]

还有其他属性我没有一一列举了,比如
> `tabTextColor` 未选中文本颜色
> `tabSelectedTextColor` 选中文本颜色
> `tabBackground` 背景颜色
> 等等

---
### TabLayout添加图片
---

上面简单的说明了`TabLayout`的`setupWithViewPager`的用法,它还有另外一种方式来添加tab,具体如下:
```
TabLayout.Tab tab = tabLayout.newTab();
tab.setIcon(R.drawable.chat_selector);//上面的图片
tab.setText("会话");
tabLayout.addTab(tab, true);//添加到layout中,并默认选择
        
tab = tabLayout.newTab();
tab.setIcon(R.drawable.friend_selector);
tab.setText("好友");
tabLayout.addTab(tab);
        
tab = tabLayout.newTab();
tab.setIcon(R.drawable.location_selector);
tab.setText("地点");
tabLayout.addTab(tab);
        
tab = tabLayout.newTab();
tab.setIcon(R.drawable.more_selector);
tab.setText("更多");
tabLayout.addTab(tab);
        
tab = tabLayout.newTab();
tab.setIcon(R.drawable.person_selector);
tab.setText("我的");
tabLayout.addTab(tab);
```

然后上面的运行是下面这种样式
![tab_2][3]
是不是有点微信的味道了,不急,因为这里只是手动添加的tab,并没有和pager联动起来,我们结合上面的`setupWithViewPager`改下,
```
        //把TabLayout关联pager
        tabLayout.setupWithViewPager(viewPager);
        
        String[] title = {"会话", "好友", "地点", "更多", "我的"};
        int[] icons = {R.drawable.chat_selector, R.drawable.friend_selector, R.drawable.location_selector, R.drawable.more_selector, R.drawable.person_selector};
        
        for (int i = 0; i < mAdapter.getCount(); i++) {
            //取得对应的tab
            TabLayout.Tab tab = tabLayout.getTabAt(i);
            if (tab != null) {
                //设置文字和图标
                tab.setText(title[i]);
                tab.setIcon(icons[i]);
            }
        }
```
运行,效果如下:
![tab_2gif][4]

这里的图标默认的显示到文字的上方,如果要显示到左边,这里提供2种解决方案:
> 可以用`SpannableString`的方式给text加图片来实现,需要注意的是需要在style里面设置`textAllCaps`为false,`Tablayout`默认关闭了图片渲染. 
> 可以自定义view来实现, ` tab.setCustomView()`,传入你自定义的view就可以了

上面2种方案我这里就不一一说明了,个人不推荐,有点违背android的设计风格,如果你要这样实现,请自行百度下,原文博客链接失效,我这里也没有了,尴尬

---
## 最后
---

`Tablayout`大致就这些了,如果有哪里需要改进和错误,请给我留言,谢谢.
下一篇我会阐述下`NavigationView`,源码会在系列结束后一起放出,谢谢支持


  [1]:http://img.perryzou.com/tab.gif
  [2]: http://img.perryzou.com/tab_1.png?imageView2/2/
  [3]: http://img.perryzou.com/tab_2.png?imageView2/2/
  [4]: http://img.perryzou.com/tab_2.gif